package com.final_project.EmpwrMe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpwrMeApplicationTests {

	@Test
	void contextLoads() {
	}

}
