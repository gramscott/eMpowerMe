package com.final_project.EmpwrMe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpwrMeApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpwrMeApplication.class, args);
	}

}
